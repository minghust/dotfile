#[[#pragma once]]#


namespace stringfilter {



} // namespace stringfilter
